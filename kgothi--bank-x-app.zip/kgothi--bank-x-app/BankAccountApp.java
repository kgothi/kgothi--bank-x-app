package bankaccountapp;

public class BankAccountApp {

	public static void main(String[] args) {
		
		
		
		/*
		 Checking chkacc1 = new Checking("Kgothatso Etsane","072275221",4351);
		 Savings savacc1 = new Savings("Dineo Mnisi","076112251",8614 );
		 
		 savacc1.showInfo();
		 System.out.println("***************");
		 chkacc1.showInfo();
		*/
		 
		 // Read a CSV file then create new accounts based on that data
	
	}

}
