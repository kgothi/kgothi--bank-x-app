package bankaccountapp;

public interface IBaseRate {
	
	default double getRateBase() {
		return 0.5;
	}
}
