package bankaccountapp;

public abstract class Account implements IBaseRate {
	// List common properties for savings and checking accounts
	private String name;
	private String sSN;
	private double balance;
	
	private static int index = 10000;
	protected String accountNumber;
	protected double rate;
	
	// Constructors to set base properties and the account
	public Account(String name, String sSN,double initDeposit) {
		this.name = name;
		this.sSN = sSN;
		balance = initDeposit;
		this.accountNumber = setAccountNumber();
		setRate();
	}
	
	public abstract void setRate();
	
	private String setAccountNumber() { 
		String lastTwoOfSSN = sSN.substring(sSN.length()-2, sSN.length());
		int uniqueID = index;
		int randomNumber = (int) (Math.random() * Math.pow(10, 3));
	return lastTwoOfSSN + uniqueID + randomNumber;
	
	}
	
	public void compound() {
		double accruedInterest = balance * (rate/100);
		balance = balance + accruedInterest;
		System.out.println("Accrrued Interrest: R" + accruedInterest);
		printBalance();
	}
	
	// List common methods - transactions
	public void deposit(double amount) {
		balance = balance + amount;
		System.out.println("Depositing R" + amount);
		printBalance();
	}
	public void withdraw(double amount) {
		balance = balance - amount;
		System.out.println("Withdrawing R" + amount);
		printBalance();
	}
	public void tranfere(String toWhere, double amount) {
		balance = balance - amount;
		System.out.println("Transfering R" + amount + " to " + toWhere);
		printBalance();
	}
	public void printBalance() {
		System.out.println("Your balance is now: R500" + balance);
	}
	
	public void showInfo() {
		System.out.println(
				"NAME: " + name +
				"ACCOUNT NUMBER: " + accountNumber +
				"BALANCE: " + balance +
				"RATE: " + rate + "%"
				);
	}
}
