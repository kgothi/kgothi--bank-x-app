package bankaccountapp;

public class Checking extends Account {
	// List the properties specific to the Checking account
	private int derbitCardNumber;
	private int derbitCardPin;
	
	// Constructor to initialize Checking account specific
	public Checking(String name, String sSN, double initDeposit) {
		super(name, sSN, initDeposit);
		accountNumber = "2" + accountNumber;
		setDerbitCard(); 
	}
	
	@Override
	public void setRate() {
		rate = getRateBase() * 0.05;
	}
	
	// List any methods specific to the Checking account
	public void setDerbitCard() {
		derbitCardNumber = (int) (Math.random() * Math.pow(10, 12));
		derbitCardPin = (int) (Math.random() * Math.pow(10, 4));
	}
	
	
	public void showInfo() {
		super.showInfo();
		System.out.println( "Your Checking Account Feature" +
				"\n Derbit Card Number: " + derbitCardNumber +
				"\n Derbit Card Pin: " + derbitCardPin 
				);
	}
	
}


